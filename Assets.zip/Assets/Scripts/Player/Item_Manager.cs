﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Manager : MonoBehaviour
{
    // Start is called before the first frame update
    void Attack()
    {
        //attack
    }
    void Heal()
    {
        //heal
    }
    void Buff()
    {
        //buffs
    }
}
