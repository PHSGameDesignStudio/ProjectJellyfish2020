﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryScript : MonoBehaviour
{
    [SerializeField] private Component m_Box1;
    [SerializeField] private Component m_Box2;
    [SerializeField] private Component m_Box3;
    [SerializeField] private Component m_Box4;
    [SerializeField] private Component m_Box5;
    [SerializeField] private Component m_Box6;
    [SerializeField] private Component m_Box7;
    [SerializeField] private Component m_Box8;
    private Texture2D[] Images = new Texture2D[]{null,null,null,null,null,null,null,null};
    void Start()
    {

    }
    // Update is called once per frame
    void Update()
    {
        
    }
    void AddItem()
    {
        
    }
}
